#ifndef ADC_H
#define ADC_H

#include <avr/io.h>
#include <stdint.h>

void init_adc(void);

#endif